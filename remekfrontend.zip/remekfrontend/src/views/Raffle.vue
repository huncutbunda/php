<template>
  <section class="container py-5">
    <h1>Nyereményjáték</h1>

    <button
        class="btn btn-success mb-4"
        @click="enterDraw"
        :disabled="!user || hasEntered"
    >
      Enter Raffle
    </button>

    <p v-if="!user" class="text-warning">
      Jelentkezz be, hogy nevezhess a sorsolásra!
    </p>
    <p v-else-if="hasEntered" class="text-info">
      Már beneveztél a sorsolásra.
    </p>

    <div v-if="message" :class="['alert', messageType]" role="alert">
      {{ message }}
    </div>

    <div class="list-group">
      <div
          v-for="entry in entries"
          :key="entry.PrizeId"
          class="list-group-item d-flex justify-content-between align-items-center"
      >
        {{ entry.user.Username }} ({{ new Date(entry.entered_at).toLocaleString() }})
        <button
            v-if="user && entry.UserId === user.UserId"
            @click="cancelEntry(entry.PrizeId)"
            class="btn btn-sm btn-danger"
        >
          Lemondás
        </button>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import axios from 'axios'

// állapotok
const entries     = ref([])
const user        = ref(null)
const message     = ref('')
const messageType = ref('')

onMounted(async () => {
  const saved = localStorage.getItem('user')
  if (saved) {
    user.value = JSON.parse(saved)
  }
  await loadEntries()
})

async function loadEntries() {
  try {
    const res = await axios.get('http://localhost:8000/api/raffle')
    entries.value = res.data
  } catch (err) {
    message.value     = 'Hiba a nevezések betöltésekor'
    messageType.value = 'alert-danger'
  }
}

const hasEntered = computed(() => {
  return user.value && entries.value.some(e => e.UserId === user.value.UserId)
})

async function enterDraw() {
  if (!user.value) return
  try {
    await axios.post('http://localhost:8000/api/raffle', {
      UserId: user.value.UserId
    })
    message.value     = 'Sikeresen beneveztél!'
    messageType.value = 'alert-success'
    await loadEntries()
  } catch (err) {
    message.value     = err.response?.data?.message || 'Hiba a nevezés során'
    messageType.value = 'alert-danger'
  }
}

async function cancelEntry(id) {
  if (!confirm('Biztos lemondod a nevezésed?')) return
  try {
    await axios.delete(`http://localhost:8000/api/raffle/${id}`)
    message.value     = 'Nevezésed törölve.'
    messageType.value = 'alert-warning'
    await loadEntries()
  } catch {
    message.value     = 'Hiba a lemondás során'
    messageType.value = 'alert-danger'
  }
}
</script>

<style scoped>
.list-group-item {
  transition: background-color 0.3s ease;
}
.list-group-item:hover {
  background-color: #f8f9fa;
}
</style>
