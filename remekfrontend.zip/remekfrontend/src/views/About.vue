<template>
<section class="container">
    <h1>Elérhetőségek:</h1>
    <p>Telefonszám: 06 70 333 9876</p>
    <p>Email: ridemania@gmail.com</p>
    <h2>Közreműködők:</h2>
    <h3>Horn Ádám Attila</h3>
    <h3>Lehel Dániel Zsolt</h3>
    <h3>Szabó Ákos Csaba</h3>
    <br>
    <h4>Üdvözlünk az AutoMania oldalán – ahol az autók és motorok iránti szenvedély találkozik a hiteles tartalommal és naprakész információval. 
        Célunk, hogy egy olyan platformot hozzunk létre, amely egyaránt kiszolgálja a járművek iránt érdeklődő rajongókat és a szakmai közönséget is.</h4>
    <h4>Weboldalunkon bemutatjuk a legismertebb autó- és motormárkákat, azok modelljeit, technikai paramétereit, 
        valamint naprakész híreket és érdekességeket is megosztunk az autó- és motorvilágból. 
        A felhasználók könnyedén böngészhetnek, szűrhetnek márkák szerint, 
        és felfedezhetik a számukra legkedvezőbb modelleket.</h4>
    <h4>Projektünket informatika iránt elkötelezett diákok hozták létre azzal a céllal, 
        hogy egy jól strukturált, felhasználóbarát felületen keresztül népszerűsítsék az autó- és motoros kultúrát. 
        Hisszük, hogy az ismeretterjesztés és a technikai érdeklődés kéz a kézben járhat, 
        és ehhez szeretnénk hozzájárulni digitális magazinunkkal.</h4>
    <h2>Köszönjük, hogy ellátogattál hozzánk – induljon a felfedezés!</h2>
</section>
</template>
<script>

</script>
<style>
    .container h1{
        color: slateblue;
    }
    p{
        color: white;
    }
    .container h4, .container h2, .container h3 {
        color: white;
    }
    body {
    background-color: black;    
    }
</style>