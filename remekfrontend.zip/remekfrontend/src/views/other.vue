<template>
<section class="container">
    <h1>Elérhetőségek</h1>
    <p>Telefonszám: 06 70 333 9876</p>
    <p>Email: igen@gmail.com</p>
</section>
</template>
<script>

</script>
<style>
    .container h1{
        color: slateblue;
    }
    p{
        color: white;
    }
</style>