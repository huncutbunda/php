<template>
  <section class="container">
    <h1>Autók listája</h1>
    <div class="row">
      <div v-for="car in cars" :key="car.id" class="col-md-4 mb-4">
        <div class="card h-100 shadow">
          <img :src="car.image" class="card-img-top" alt="Autó kép" v-if="car.image">
          <div class="card-body">
            <img :src="car.Image" alt="Car Image" class="card-img-top" />
            <h4 style="color: black;" class="card-title">{{ car.brand.BrandName }} {{ car.Model.toUpperCase() }}</h4>
            <p class="card-text"><strong>HP:</strong> {{ car.Horsepower }}</p>
            <p class="card-text"><strong>Color:</strong> {{ car.Color}}</p>
            <p class="card-text"><strong>Price:</strong> {{ car.Price }} eur</p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const cars = ref([])

onMounted(async () => {
  try {
    const response = await axios.get('http://localhost:8000/api/cars')
    cars.value = response.data
  } catch (error) {
    alert('Hiba történt az autók betöltésekor: ' + error)
  }
})
</script>

<style scoped>
.card-img-top {
  height: 300px;
  object-fit: cover;
}
.card-text{
  color: black !important;
}
</style>