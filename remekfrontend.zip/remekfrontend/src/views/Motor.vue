<template>
  <section class="container">
    <h1>Motorok listája</h1>
    <div class="row">
      <div v-for="motor in motors" :key="motor.id" class="col-md-4 mb-4">
        <div class="card h-100 shadow">
          <img :src="motor.image" class="card-img-top" alt="Autó kép" v-if="motor.image">
          <div class="card-body">
            <img :src="motor.Image" alt="Motor Image" class="card-img-top" />
            <h4 style="color: black;" class="card-title">{{ motor.brand.BrandName }} {{ motor.Model.toUpperCase() }}</h4>
            <p class="card-text"><strong>HP:</strong> {{ motor.Horsepower }}</p>
            <p class="card-text"><strong>Color:</strong> {{ motor.Color}}</p>
            <p class="card-text"><strong>Price:</strong> {{ motor.Price }} eur</p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const motors = ref([])

onMounted(async () => {
  try {
    const response = await axios.get('http://localhost:8000/api/motors')
    motors.value = response.data
  } catch (error) {
    alert('Hiba történt az autók betöltésekor: ' + error)
  }
})
</script>

<style scoped>
.card-img-top {
  height: 300px;
  object-fit: cover;
}
.card-text{
  color: black !important;
}
</style>