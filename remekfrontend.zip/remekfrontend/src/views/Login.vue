<template>
  <section class="container py-5">
    <div v-if="!user" id="loginoldal" class="mx-auto" style="max-width: 500px;">
      <div class="card shadow-lg p-3 mb-5 bg-body-tertiary rounded-4">
        <div class="card-body">
          <h2 class="mb-4" style="color:Black; text-align:center">Bejelentkezés</h2>
          <div v-if="errorMessage" class="alert alert-danger">{{ errorMessage }}</div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input v-model="email" type="email" class="form-control" />
          </div>
          <div class="mb-3">
            <label class="form-label">Jelszó</label>
            <input v-model="password" type="password" class="form-control" />
          </div>
          <button @click="login" class="btn btn-primary w-100">Bejelentkezés</button>
        </div>
      </div>
    </div>

    <div v-else class="mx-auto" style="max-width: 600px;">
      <div class="card shadow-lg p-3 mb-5 bg-body-tertiary rounded-4">
        <div class="card-body">
          <h2 class="mb-4">Profilom</h2>

          <div class="mb-3">
            <label class="form-label">Felhasználónév</label>
            <input v-model="form.Username" type="text" class="form-control" />
          </div>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input v-model="form.Email" type="email" class="form-control" />
          </div>

          <div class="mb-3">
            <label class="form-label">Telefonszám</label>
            <input v-model="form.Number" type="text" class="form-control" />
          </div>

          <div class="mb-3">
            <label class="form-label">Új jelszó (opcionális)</label>
            <input v-model="form.Password" type="password" class="form-control" />
          </div>

          <div class="d-flex justify-content-between">
            <button @click="updateProfile" class="btn btn-success">Mentés</button>
            <button @click="deleteAccount" class="btn btn-danger">Fiók törlése</button>
            <button @click="logout" class="btn btn-secondary">Kijelentkezés</button>
          </div>

          <div v-if="successMessage" class="alert alert-success mt-3">{{ successMessage }}</div>
          <div v-if="errorMessage" class="alert alert-danger mt-3">{{ errorMessage }}</div>
        </div>
      </div>
    </div>
  </section>
</template>
<script setup>
import { ref, reactive, onMounted } from 'vue'
import axios from 'axios'

const user = ref(null)
const email = ref('')
const password = ref('')
const form = reactive({ Username: '', Email: '', Number: '', Password: '' })
const errorMessage = ref('')
const successMessage = ref('')

onMounted(() => {
  const saved = localStorage.getItem('user')
  if (saved) {
    user.value = JSON.parse(saved)
    Object.assign(form, user.value)
  }
})

async function login() {
  errorMessage.value = ''
  try {
    const { data } = await axios.post('http://localhost:8000/api/login', {
      Email: email.value,
      Password: password.value
    })
    user.value = data.user
    // copy into form
    Object.assign(form, data.user)
    localStorage.setItem('user', JSON.stringify(data.user))
    successMessage.value = ''
  } catch (err) {
    errorMessage.value = err.response?.data?.message || 'Ismeretlen hiba történt'
  }
}

async function updateProfile() {
  errorMessage.value = ''
  successMessage.value = ''
  try {
    // prepare payload, skip empty password
    const payload = {
      Username: form.Username,
      Email: form.Email,
      Number: form.Number
    }
    if (form.Password) payload.Password = form.Password

    const { data } = await axios.put(
        `http://localhost:8000/api/users/${user.value.UserId}`,
        payload
    )

    user.value = data
    Object.assign(form, data)
    localStorage.setItem('user', JSON.stringify(data))
    successMessage.value = 'Profil sikeresen frissítve!'
  } catch (err) {
    if (err.response?.data?.errors) {
      errorMessage.value = Object.values(err.response.data.errors)
          .flat().join('; ')
    } else {
      errorMessage.value = err.response?.data?.message || 'Frissítési hiba'
    }
  }
}

async function deleteAccount() {
  if (!confirm('Biztosan törlöd a fiókodat?')) return
  try {
    await axios.delete(`http://localhost:8000/api/users/${user.value.UserId}`)
    logout()
  } catch {
    errorMessage.value = 'Fiók törlése sikertelen'
  }
}

function logout() {
  user.value = null
  localStorage.removeItem('user')
  email.value = ''
  password.value = ''
  errorMessage.value = ''
  successMessage.value = ''
}
</script>
<style>
body {
  background-image: url(e39.jpg);
}

 #loginresz {
    background-color: slategrey;
 }

 #logingombresz {
    text-align: center;
 }

 #logingomb {
    width: 100%;
    background-color: slateblue;
 }


</style>