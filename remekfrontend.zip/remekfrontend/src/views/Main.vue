<template>
  <section class="container">
    <h1 style="text-align:center">AutóMánia</h1>
    <div class="container">
      <div class="d-flex flex-row justify-content-around">
        <div :class="['options align-items-center', hovered === 'car' ? 'col-6' : 'col-5']" @mouseover="hovered = 'car'"
             @mouseleave="hovered = ''">
          <h1>Autók</h1>
          <RouterLink to="/cars"><img class="kep" src="../../public/e30.jpg" alt="Car"></RouterLink>
        </div>
        <div :class="['options', hovered === 'motor' ? 'col-6' : 'col-5']" @mouseover="hovered = 'motor'"
             @mouseleave="hovered = ''">
          <h1>Motorok</h1>
          <RouterLink to="/motors"><img class="kep" src="../../public/Bobber_Black_hero_RHS-scaled.jpg" alt="Motorcycle" ></RouterLink>%
        </div>
      </div>
    </div>
  </section>
</template>
<script>
export default {
  data() {
    return {
      hovered: ''
    }
  }
}
</script>
<style>
.kep {
  height: 300px;
  width: 100%;
  overflow: hidden;
  transition: all 0.4s ease;
  cursor: pointer;
}
.options{
  text-align: center;
}

</style>