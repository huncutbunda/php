<template>
    <section class="container">
        <h1>Főoldal</h1>
        <img id="M5COMPETITIONANYAD" src="../../e30.jpg" alt="">
        
    </section>
</template>
<script>

</script>
<style>
#M5COMPETITIONANYAD{
    width: 100%;
}
</style>