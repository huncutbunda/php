<template>
  <section class="position-absolute top-50 start-50 translate-middle">
    <div class="card shadow-lg p-3 mb-5 bg-body-tertiary rounded-4" style="width: 45rem;">
      <div class="card-body">
        <h2 class="mb-4" style="color:Black; text-align:center">Regisztráció</h2>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Email</label>
          <div class="col-sm-9">
            <input type="email" class="form-control" v-model="form.Email">
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Username</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" v-model="form.Username">
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Jelszó</label>
          <div class="col-sm-9">
            <input type="password" class="form-control" v-model="form.Password">
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Jelszó mégegyszer</label>
          <div class="col-sm-9">
            <input type="password" class="form-control" v-model="form.PasswordAgain">
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Telefonszám</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" v-model="form.Number">
          </div>
        </div>
        <div class="col-auto">
          <button type="submit" @click="registerUser" class="btn btn-primary mb-3" id="reggomb">Regisztráció</button>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      form: {
        Email: '',
        LastName: '',
        FirstName: '',
        Password: '',
        PasswordAgain: '',
        Number: ''
      }
    }
  },
  methods: {
    async registerUser() {
      if (this.form.Password !== this.form.PasswordAgain) {
        alert("A két jelszó nem egyezik!");
        return;
      }

      try {
        await axios.post('http://localhost:8000/api/users', {
          Username: this.form.Username,
          Email: this.form.Email,
          Password: this.form.Password,
          Number: this.form.Number
        });

        alert("Sikeres regisztráció!");
      } catch (error) {
        console.error(error);
        alert("Ismeretlen hiba:\n" + JSON.stringify(error.response.data));
        alert("Hiba a regisztráció során.");
      }
    }
  }
}
</script>

<style>
#reggomb {
    width: 100%;
    background-color: slateblue;
 }
</style>