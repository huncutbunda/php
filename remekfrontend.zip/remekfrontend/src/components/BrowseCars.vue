<template>
    <div class="container mt-5">
      <h2 class="mb-4">Autók böngészése</h2>
      <div class="row">
        <div class="col-md-4 mb-4" v-for="car in cars" :key="car.id">
          <div class="card h-100 shadow-sm">
            <img :src="car.image" class="card-img-top" :alt="car.model">
            <div class="card-body">
              <h5 class="card-title">{{ car.brand.brandname }} {{ car.model }}</h5>
              <p class="card-text">
                <strong>Teljesítmény:</strong> {{ car.horsepower }} LE<br>
                <strong>Szín:</strong> {{ car.color }}<br>
                <strong>Ár:</strong> {{ car.price }} eur<br>
              </p>
            </div>
          </div>
        </div>
      </div>
      <p v-if="cars.length === 0 && !loading">Nincs elérhető autó.</p>
      <div v-if="loading" class="text-center mt-4">
        <div class="spinner-border text-primary" role="status"><span class="visually-hidden">Töltés...</span></div>
      </div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    name: 'BrowseCars',
    data() {
      return {
        cars: [],
        loading: true
      };
    },
    mounted() {
      axios.get('/api/cars') 
        .then(response => {
          this.cars = response.data;
        })
        .catch(error => {
          console.error('Hiba történt az adatok betöltése közben:', error);
        })
        .finally(() => {
          this.loading = false;
        });
    }
  };
  </script>
  
  <style scoped>
  .card-img-top {
    max-height: 200px;
    object-fit: cover;
  }
  </style>
  