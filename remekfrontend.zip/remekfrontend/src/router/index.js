import login from '@/views/Login.vue'
import main from '@/views/Main.vue'
import about from '@/views/About.vue'
import register from '@/views/Register.vue'
import car from '@/views/Car.vue'
import raffle from '@/views/Raffle.vue'
import motor from '@/views/Motor.vue'
import { createRouter, createWebHistory } from 'vue-router'
//import BrowseCars from '/src/components/BrowseCars.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'Main',
      component: main,
    },
    {
      path: '/login',
      name: 'Login',
      component: login,
    },
    {
      path: '/register',
      name: 'Register',
      component: register,
    },
    {
      path: '/about',
      name: 'About',
      component: about,
    },
    {
      path:'/cars',
      name:'Car',
      component:car,
    },
    {
      path:'/motors',
      name:'Motor',
      component:motor,
    },
    {
      path:'/raffle',
      name:'Raffle',
      component:raffle,
    }
    /*{
      path: '/cars',
      name: 'BrowseCars',
      component: BrowseCars
    }
      */
  ],
})


export default router