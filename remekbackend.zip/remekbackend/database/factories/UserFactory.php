<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\user>
 */
class UserFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'Username' => $this->faker->userName,
            'Password' => $this->faker->password(8, 10),
            'Email' => $this->faker->email,
            'Number' => $this->faker->randomNumber(5),
            'created_at' => now(),
        ];
    }

}
