<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Brand;
/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\car>
 */
class CarFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'Model' => $this->faker->word,
            'Horsepower' => (string) $this->faker->numberBetween(50, 500),
            'Color' => $this->faker->safeColorName,
            'Price' => $this->faker->numberBetween(10000, 100000),
            'Image' => '../public/No-Image-Placeholder.svg.png',
            'BrandId' => Brand::factory(),
        ];
    }

}
