<?php

namespace Database\Factories;

use App\Models\raffle;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class RaffleFactory extends Factory
{
    protected $model = raffle::class;

    public function definition(): array
    {
        return [
            'UserId'     => User::factory(),
            'entered_at' => now()->subMinutes(rand(0, 1440)),
        ];
    }
}
