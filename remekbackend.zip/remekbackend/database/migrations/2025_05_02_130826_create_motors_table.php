<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('motors', function (Blueprint $table) {
            $table->id('MotorId');
            $table->string('Model', 100);
            $table->string('Horsepower', 7);
            $table->string('Color', 10);
            $table->integer('Price');
            $table->string('Image');
            $table->unsignedBigInteger('BrandId');

            $table->foreign('BrandId')->references('BrandId')->on('brands')->onDelete('cascade');
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('motors');
    }
};
