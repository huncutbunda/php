<?php

use App\Http\Controllers\CarController;
use App\Http\Controllers\MotorController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\RaffleController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');


Route::apiResource('cars', CarController::class);
Route::apiResource('motors', MotorController::class);
Route::apiResource('users', UserController::class);
Route::apiResource('brands', BrandController::class);
;

Route::apiResource('raffle', RaffleController::class)
    ->only(['index', 'store', 'destroy']);

Route::post('/login', [UserController::class, 'login']);
Route::get('/cars', [CarController::class, 'index']);
