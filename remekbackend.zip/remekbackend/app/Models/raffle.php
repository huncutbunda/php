<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class raffle extends Model
{
    use HasFactory;

    protected $primaryKey = 'PrizeId';
    public $timestamps = false;

    protected $fillable = ['UserId', 'entered_at'];

    public function user()
    {
        return $this->belongsTo(User::class, 'UserId');
    }
}
