<?php

namespace App\Http\Controllers;

use App\Models\Motor;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class motorController extends Controller
{
    public function index()
    {
        $motors = Motor::all();
        //return response()->json($motors);
        return Motor::with('brand')->get();
    }

    public function show($id){
        $motor = Motor::find($id);

        if (!$motor) {
            return response()->json(['message' => 'motor not found'], Response::HTTP_NOT_FOUND);
        }

        return response()->json($motor);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'Model' => 'required|string|max:100',
            'Horsepower' => 'required|string|max:7',
            'Color' => 'required|string|max:10',
            'Price' => 'required|integer',
            'BrandId' => 'required|exists:brands,BrandId',
        ]);

        $motor = Motor::create($validated);

        return response()->json($motor, Response::HTTP_CREATED);
    }

    public function update(Request $request, $id)
    {
        $motor = Motor::find($id);

        if (!$motor) {
            return response()->json(['message' => 'motor not found'], Response::HTTP_NOT_FOUND);
        }

        $validated = $request->validate([
            'Model' => 'required|string|max:100',
            'Horsepower' => 'required|string|max:7',
            'Color' => 'required|string|max:10',
            'Price' => 'required|integer',
            'BrandId' => 'required|exists:brands,BrandId',
        ]);

        $motor->update($validated);

        return response()->json($motor);
    }

    public function destroy($id)
    {
        $motor = Motor::find($id);

        if (!$motor) {
            return response()->json(['message' => 'motor not found'], Response::HTTP_NOT_FOUND);
        }

        $motor->delete();

        return response()->json(['message' => 'motor deleted successfully']);
    }
}
