<?php

namespace App\Http\Controllers;

use App\Models\raffle;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class RaffleController extends Controller
{
    public function index()
    {
        $entries = raffle::with('user')->get();
        return response()->json($entries, Response::HTTP_OK);
    }
    public function store(Request $request)
    {
        $data = $request->validate([
            'UserId' => 'required|exists:users,UserId',
        ]);

        if (raffle::where('UserId', $data['UserId'])->exists()) {
            return response()->json([
                'message' => 'Már beneveztél a sorsolásra.'
            ], Response::HTTP_CONFLICT);
        }

        $entry = raffle::create($data);
        return response()->json($entry, Response::HTTP_CREATED);
    }

    public function destroy($id)
    {
        $entry = raffle::find($id);
        if (!$entry) {
            return response()->json(['message' => 'Nincs ilyen nevezés.'], Response::HTTP_NOT_FOUND);
        }
        $entry->delete();
        return response()->json(null, Response::HTTP_NO_CONTENT);
    }
}
