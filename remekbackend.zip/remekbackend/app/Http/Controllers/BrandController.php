<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class BrandController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $brands = Brand::all();
        return response()->json($brands, Response::HTTP_OK);
    }

    /**
     * Store a newly created brand in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'Name' => 'required|string|max:100|unique:brands,Name'
        ]);

        $brand = Brand::create($validated);

        return response()->json($brand, Response::HTTP_CREATED);
    }

    /**
     * Display the specified brand.
     */
    public function show(Brand $brand)
    {
        return response()->json($brand, Response::HTTP_OK);
    }

    /**
     * Update the specified brand in storage.
     */
    public function update(Request $request, Brand $brand)
    {
        $validated = $request->validate([
            'Name' => 'required|string|max:100|unique:brands,Name,' . $brand->id
        ]);

        $brand->update($validated);

        return response()->json($brand, Response::HTTP_OK);
    }

    /**
     * Remove the specified brand from storage.
     */
    public function destroy(Brand $brand)
    {
        $brand->delete();

        return response()->json(['message' => 'Brand deleted successfully'], Response::HTTP_NO_CONTENT);
    }
}
