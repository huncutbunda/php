<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'Email'    => 'required|email',
            'Password' => 'required|string',
        ]);

        $user = User::where('Email', $credentials['Email'])->first();

        if (!$user || !Hash::check($credentials['Password'], $user->Password)) {
            return response()->json([
                'message' => 'Hibás email vagy jelszó'
            ], Response::HTTP_UNAUTHORIZED);
        }

        return response()->json([
            'message' => 'Sikeres bejelentkezés',
            'user' => $user
        ], Response::HTTP_OK);
    }

    /**
     * Display a listing of users.
     */
    public function index()
    {
        $users = User::all();
        return response()->json($users, Response::HTTP_OK);
    }

    /**
     * Store a newly created user in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'Username' => 'required|string|max:100|unique:users,Username',
            'Password' => 'required|string|min:8',
            'Email'    => 'required|email|max:100|unique:users,Email',
            'Number'   => 'required|string',
        ]);

        $validated['Password'] = bcrypt($validated['Password']);

        $user = User::create($validated);

        return response()->json($user, Response::HTTP_CREATED);
    }

    /**
     * Display the specified user.
     */
    public function show(User $user)
    {
        return response()->json($user, Response::HTTP_OK);
    }

    /**
     * Update the specified user in storage.
     */
    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'Username' => 'sometimes|string|max:100|unique:users,Username,' . $user->UserId . ',UserId',
            'Password' => 'sometimes|string|min:8',
            'Email'    => 'sometimes|email|max:100|unique:users,Email,' . $user->UserId . ',UserId',
            'Number'   => 'sometimes|string',
        ]);

        if (isset($validated['Password'])) {
            $validated['Password'] = bcrypt($validated['Password']);
        }

        $user->update($validated);

        return response()->json($user, Response::HTTP_OK);
    }

    /**
     * Remove the specified user from storage.
     */
    public function destroy(User $user)
    {
        $user->delete();

        return response()->json([
            'message' => 'User deleted successfully'
        ], Response::HTTP_NO_CONTENT);
    }
}
