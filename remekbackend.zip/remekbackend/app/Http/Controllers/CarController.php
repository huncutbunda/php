<?php

namespace App\Http\Controllers;

use App\Models\Car;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class CarController extends Controller
{
    public function index()
    {
        $cars = Car::all();
        //return response()->json($cars);

        return Car::with('brand')->get();
    }

    public function show($id)
    {
        $car = Car::find($id);

        if (!$car) {
            return response()->json(['message' => 'Car not found'], Response::HTTP_NOT_FOUND);
        }

        return response()->json($car);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'Model' => 'required|string|max:100',
            'Horsepower' => 'required|string|max:7',
            'Color' => 'required|string|max:10',
            'Price' => 'required|integer',
            'BrandId' => 'required|exists:brands,BrandId',
        ]);

        $car = Car::create($validated);

        return response()->json($car, Response::HTTP_CREATED);
    }

    public function update(Request $request, $id)
    {
        $car = Car::find($id);

        if (!$car) {
            return response()->json(['message' => 'Car not found'], Response::HTTP_NOT_FOUND);
        }

        $validated = $request->validate([
            'Model' => 'required|string|max:100',
            'Horsepower' => 'required|string|max:7',
            'Color' => 'required|string|max:10',
            'Price' => 'required|integer',
            'BrandId' => 'required|exists:brands,BrandId',
        ]);

        $car->update($validated);

        return response()->json($car);
    }

    public function destroy($id)
    {
        $car = Car::find($id);

        if (!$car) {
            return response()->json(['message' => 'Car not found'], Response::HTTP_NOT_FOUND);
        }

        $car->delete();

        return response()->json(['message' => 'Car deleted successfully']);
    }


}
